input="1f.graph.edgelist"  
> x.txt                                                                         #Reinitialize File
while IFS= read -r line                                                         #Read
do
        IFS=" " read -r -a array <<< "$line"	                                #Read Sepreated out " "
        NUMBER=${array[0]}
        NUMBER1=${array[1]}
        if [[ $NUMBER == *"["* ]];                                              #file given has some error
        then    
                NUMBER=$NUMBER                                                  #Error in the given File
        elif [ $NUMBER -lt $NUMBER1 ];
        then
                echo "$NUMBER1 $NUMBER">> x.txt        
        elif [ $NUMBER -gt $NUMBER1 ];
        then
                echo "$NUMBER $NUMBER1">> x.txt
        fi
done < "$input"                                     
awk -F $' ' ' { t = $1; $1 = $2; $2 = t; print; } ' OFS=$' ' x.txt > y.txt    
sort -u y.txt > 1f_output_graph.edgelist                                        #Cleaned Output                    
awk ' { t = $1; $1 = $2; $2 = t; print; } ' 1f_output_graph.edgelist > x.txt    #reverse output and write in x.txt
cat 1f_output_graph.edgelist >> x.txt                                           #append clean in x.txt 
awk -F" " '{print $1}' x.txt > y.txt                                            #just Take first column of x.txt to find Degree
tr ' ' '\12' <y.txt| sort | uniq -c | sort -nr > x.txt                          #Frequency of the Number will give Degree
echo "Node Degree Respectively in Descending Order of Degree " > ANS.txt
awk -F $' ' ' { t = $1; $1 = $2; $2 = t; print; } ' OFS=$' ' x.txt >> ANS.txt   # Node # Degree
rm x.txt                                                                        #Remove Not Needed Files
rm y.txt                                                                        #Remove Not Needed Files