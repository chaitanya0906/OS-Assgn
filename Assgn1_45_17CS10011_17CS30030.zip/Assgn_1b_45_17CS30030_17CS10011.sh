echo "serial      Random string " > output.txt	#Writing First Line
cnt=1						#CNT
input="1b_input.txt"				#Input File
while IFS= read -r line				#Read
do
	echo "$cnt           $line" >> output.txt	#Output File
	let "cnt++"
done < "$input"	