#17CS10011
#17CS30030

echo "First Number: $1"
echo "Assignment : $2"
echo "Second Number: $3"

#Multiplt case
#Star being WildCard case it gives some errors please specify as \*

if [ "$2" = "+" ]; #Add
then
	val=`expr $1 + $3`
elif [ "$2" = "-" ]; #Substract
then
	val=`expr $1 - $3`
elif [ "$2" = "/" ];	#Divide
then
	val=`expr $1 / $3`
elif [ "$2" = "%" ];	#mod
then	
	val=`expr $1 % $3`
else			#Multiply
	val=`expr $1 \* $3`
fi
echo "Value : $val"