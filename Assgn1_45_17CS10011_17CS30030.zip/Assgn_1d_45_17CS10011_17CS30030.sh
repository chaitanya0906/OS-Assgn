if [ ! -d "1.d.files.out" ];	# No Need to create if already exists
then
	mkdir 1.d.files.out
fi

cnt=1
for f in 1.d.files/*.txt; do	#Iterating over Files
	y="1.d.files.out/"
	y+=$cnt
	y+=".txt"
	see+=y
	sort -nr $f > $y	#reverse Sorting Numerically
	cnt=`expr $cnt + 1`
done
sort -m -nr 1.d.files.out/*.txt > 1.d.out.txt	#Merging reverse sorted Files