string=$1
IFS=',' read -r -a array <<< "$string"	#Read Sepreated out ,

gcd(){					#Euclidean GCD 
	a=$1
	b=$2
	while [ $a -ne 0 -a $b -ne 0 ]; do
		if [ $a -lt $b ]
		then
			b=$((b%a))
		else

			a=$((a%b))
		fi	
		#statements
	done
	return $((a+b))
}

var=0
for element in "${array[@]}";
do
	gcd $var $element
	var=$?
done
echo "GCD of the Input Numbers is : $var"